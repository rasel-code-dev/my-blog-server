const a = "name"
export  default a